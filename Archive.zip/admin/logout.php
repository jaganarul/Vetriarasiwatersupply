<?php
require_once __DIR__ . '/../init.php';
unset($_SESSION['admin_id'], $_SESSION['admin_name']);
header('Location: login.php'); exit;
?>